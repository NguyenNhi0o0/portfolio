<footer>
    <div class="social-icons">
        <a href="" target="_blank">
            <i class="fab fa-twitter fa-2x"></i>
        </a>
        <a href="" target="_blank">
            <i class="fab fa-facebook fa-2x"></i>
        </a>
        <a href="" target="_blank">
            <i class="fab fa-instagram fa-2x"></i>
        </a>
        <a href="" target="_blank">
            <i class="fab fa-github fa-2x"></i>
        </a>
        <a href="@content('linkedin')" target="_blank">
            <i class="fab fa-linkedin fa-2x"></i>
        </a>
    </div>
    &copy; @content('copyright')
</footer>
