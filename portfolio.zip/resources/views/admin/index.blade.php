@extends('admin.layoutsAdmin.app')

@section('content')
    <nav class="nav flex-column">
        <a class="nav-link active" aria-current="page" href="/contents">Content</a>
        <a class="nav-link" href="/projects">Project</a>
        <a class="nav-link" href="/educations">Formation</a>
        <a class="nav-link" href="/experiences">Experience</a>
        <a class="nav-link" href="/contacts">Contact</a>
        <a class="nav-link" href="/images">Image</a>
    </nav>
@endsection
